using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using sib_api_v3_sdk.Api;
using sib_api_v3_sdk.Client;
using sib_api_v3_sdk.Model;
using System.ComponentModel.DataAnnotations;

namespace emailapi.Pages
{
    public class EmailsModel : PageModel
    {
        [BindProperty, Required]
        public string Username { get; set; } = "";

        [BindProperty, Required, EmailAddress]
        public string Email { get; set; } = "";

        [BindProperty, Required]
        public string Subject { get; set; } = "";

        [BindProperty, Required]
        public string Message { get; set; } = "";


        private readonly string apiKey = "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";


        public void OnGet()
        {
        }

        public string successMessage = "";
        public string errorMessage = "";

        public void OnPost()
        {
            if (!ModelState.IsValid)
            {
                errorMessage = "Please fill all the required fields";
                return;
            }




            Configuration.Default.ApiKey["api-key"] = apiKey;

            var apiInstance = new TransactionalEmailsApi();

            string SenderName = "Best Store";
            string SenderEmail = "aakankshau75@gmail.com";
            SendSmtpEmailSender emailSender = new SendSmtpEmailSender(SenderName, SenderEmail);

            SendSmtpEmailTo emailReceiver1 = new SendSmtpEmailTo(Email, Username);
            List<SendSmtpEmailTo> To = new List<SendSmtpEmailTo>();
            To.Add(emailReceiver1);



            string HtmlContent = null;
            string TextContent = Message;


            try
            {
                var sendSmtpEmail = new SendSmtpEmail(emailSender, To, null, null, HtmlContent, TextContent, Subject);
                CreateSmtpEmail result = apiInstance.SendTransacEmail(sendSmtpEmail);
                Console.WriteLine("Response:\n" + result.ToJson());
                successMessage = "Your message has been transmitted successfully";
            }
            catch (Exception e)
            {
                errorMessage = e.Message;
                Console.WriteLine("We have an Exception:\n" + e.Message);
            }


        }
    }
}
